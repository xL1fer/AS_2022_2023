/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package HCP.BedRoom;

/**
 *
 * Bed Room monitor.
 */
public interface IBedRoom extends IBedRoom_Customer, IBedRoom_Porter, IBedRoom_ControlCentreProxy {
    
}
