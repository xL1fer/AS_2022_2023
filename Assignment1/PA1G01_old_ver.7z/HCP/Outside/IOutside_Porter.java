/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package HCP.Outside;

import HCP.ActiveEntity.TPorter;

/**
 *
 * Outside Porter interface.
 */
public interface IOutside_Porter {
    /**
     * Porter reset simulation.
     */
    void resetSimulation();
    /**
     * Porter call customers to enter the hostel.
     * 
     * @param count number of customers
     */
    void comeIn(int count);
    /**
     * Porter wait for customers to enter the hostel.
     * 
     * @param porter porter object
     */
    void waitEntrance(TPorter porter);
}
