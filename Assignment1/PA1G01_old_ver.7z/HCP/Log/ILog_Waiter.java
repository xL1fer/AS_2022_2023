/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package HCP.Log;

/**
 *
 * Log Waiter interface.
 */
public interface ILog_Waiter {
    /**
     * Waiter log serving.
     * 
     * @param seatNumber table seat number
     */
    void waiter_logServing(int seatNumber);
}
