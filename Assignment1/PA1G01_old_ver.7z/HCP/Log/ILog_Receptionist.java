/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package HCP.Log;

/**
 *
 * Log Receptionist interface.
 */
public interface ILog_Receptionist {
    /**
     * Receptionist log call.
     * 
     * @param receptionistId receptionist id
     */
    void receptionist_logCall(int receptionistId);
}
