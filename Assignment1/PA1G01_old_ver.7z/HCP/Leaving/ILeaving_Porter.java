/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package HCP.Leaving;

import HCP.ActiveEntity.TPorter;

/**
 *
 * Leaving Porter interface.
 */
public interface ILeaving_Porter {
    /**
     * Porter wait for customers' arrival.
     * 
     * @param porter porter object
     */
    void waitArrival(TPorter porter);
    /**
     * Porter open front door for customers to exit the hostel.
     * 
     * @param porter porter object
     */
    void openDoor(TPorter porter);
}
