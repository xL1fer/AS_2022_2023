/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package HCP.CheckIn;

import HCP.ActiveEntity.TCustomer;

/**
 *
 * Check In Customer interface.
 */
public interface ICheckIn_Customer {
    /**
     * Customer wait in check-in queue.
     * 
     * @param customer customer object
     */
    void inQueue(TCustomer customer);
    /**
     * Customer do check-in.
     * 
     * @param customer customer object
     */
    void checkIn(TCustomer customer);
}
