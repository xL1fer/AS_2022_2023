/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package HCP.CheckIn;

import HCP.ActiveEntity.TPorter;

/**
 *
 * Check In Porter interface.
 */
public interface ICheckIn_Porter {
    /**
     * Porter wait check-in completion.
     * 
     * @param porter porter object
     * @return true if check-in is not yet completed
     */
    boolean waitCheckIn(TPorter porter);
}
