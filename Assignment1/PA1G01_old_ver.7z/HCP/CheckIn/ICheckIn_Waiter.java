/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package HCP.CheckIn;

import HCP.ActiveEntity.TWaiter;

/**
 *
 * Check In Waiter interface.
 */
public interface ICheckIn_Waiter {
    /**
     * Waiter get total customers in the hostel.
     * 
     * @param waiter waiter object
     */
    void getTotalCustomers(TWaiter waiter);
}
