/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package HCP.BedRoom;

import HCP.ActiveEntity.TPorter;

/**
 *
 * Bead Room Porter interface.
 */
public interface IBedRoom_Porter {
    /**
     * Porter reset checkout.
     * 
     * @param porter porter object
     * @return true if there are more checkouts to be done
     */
    boolean resetCheckOut(TPorter porter);
}
