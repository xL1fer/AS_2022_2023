/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package HCP.BedRoom;

import HCP.ActiveEntity.TCustomer;

/**
 *
 * Bead Room Customer interface.
 */
public interface IBedRoom_Customer {
    /**
     * Customer go to bed.
     * 
     * @param customer customer object
     */
    void goToBed(TCustomer customer);
    /**
     * Customer wait bathroom.
     * 
     * @param customer customer object
     */
    void waitBathroom(TCustomer customer);
    /**
     * Customer use bathroom.
     * 
     * @param customer customer object
     */
    void useBathroom(TCustomer customer);
}
