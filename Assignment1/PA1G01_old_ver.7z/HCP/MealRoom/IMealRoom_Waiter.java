/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package HCP.MealRoom;

import HCP.ActiveEntity.TWaiter;

/**
 *
 * Meal Room Waiter interface.
 */
public interface IMealRoom_Waiter {
    /**
     * Waiter waits for customers.
     * 
     * @param waiter waiter object
     * @return true if there are still more floors to be served
     */
    boolean waitCustomers(TWaiter waiter);
    /**
     * Waiter serves breakfast to each customer.
     * 
     * @return true if there are still more customers to be served
     */
    boolean serveBreakfast();
}
