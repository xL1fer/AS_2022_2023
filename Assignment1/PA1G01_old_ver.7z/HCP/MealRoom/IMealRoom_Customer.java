/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package HCP.MealRoom;

import HCP.ActiveEntity.TCustomer;

/**
 *
 * Meal Room Customer interface.
 */
public interface IMealRoom_Customer {
    /**
     * Customer wait for breakfast.
     * 
     * @param customerId customer id
     */
    void waitBreakfast(TCustomer customerId);
    /**
     * Customer take breakast.
     * 
     * @param customerId customer id
     */
    void takeBreakfast(TCustomer customerId);
}
