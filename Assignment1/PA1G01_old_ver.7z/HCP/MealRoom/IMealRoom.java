/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package HCP.MealRoom;

/**
 *
 * Meal Room general interface.
 */
public interface IMealRoom extends IMealRoom_Customer, IMealRoom_Waiter, IMealRoom_ControlCentreProxy {
    
}
